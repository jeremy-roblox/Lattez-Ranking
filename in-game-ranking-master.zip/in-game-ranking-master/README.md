![banner](https://i.gyazo.com/b8a8c4e370ebd880abdcd7e9f1fad19e.png)
![description](https://i.gyazo.com/98b3aca8ea1a649dac74cc79dbd71ca1.png)

**Getting Started**  
In Game Ranking provides you a way to rank users in a Roblox group through a Roblox game. It's free, easy to setup, and unbranded! The instructions to set it up and host it are available here: https://github.com/yogurtsyum/in-game-ranking/wiki/setup

There is currently 1 branches of In Game Ranking available:  
`master` - The latest version of In Game Ranking with many features.

**Support**   
If at any time while using qbot you need support with it, then feel free to join our support server here: https://discord.gg/J47m7t4.

**Other Information**   
License: https://github.com/yogurtsyum/in-game-ranking/blob/master/LICENSE  
Acknowledgements: https://github.com/yogurtsyum/in-game-ranking/blob/master/acknowledgements.md  
Contributors: https://github.com/yogurtsyum/in-game-ranking/graphs/contributors   

Please note we are not responsible for if anything happens to your bot account. It is your responsibility to keep the cookie and key away from anyone you don't trust. In Game Ranking uses noblox.js to interact with Roblox API with your bot cookie. Do not share your .env file with anyone once filled out.

It is your responsibility to make sure your use of In Game Ranking is not against the TOS of any services it uses.
